package com.event_managment.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.event_managment.Entity.Attendee;
import com.event_managment.service.AttendeeService;

@RestController
public class AttendeeController {

	@Autowired
	private AttendeeService service;

	@PostMapping("/attendee")
	public ResponseEntity<Attendee> saveAttendee(@RequestBody Attendee attendee) {

		return service.saveAttendee(attendee);
	}

	@GetMapping("/attendee/{id}")
	public ResponseEntity<Attendee> findAttendee(@PathVariable int id) {

		return service.findAttendee(id);
	}

	@PutMapping("/attendee/{id}")
	public ResponseEntity<Attendee> updateAttendee(@PathVariable int id, @RequestBody Attendee attendee) {

		return service.updateAttendee(attendee, id);
	}

	@DeleteMapping("/attendee/{id}")
	public ResponseEntity<Attendee> deleteAttendee(@PathVariable int id, @RequestBody Attendee attendee) {

		return service.deleteAttendee(attendee, id);
	}
}
