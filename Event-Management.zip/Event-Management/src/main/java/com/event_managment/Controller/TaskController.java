package com.event_managment.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.event_managment.Entity.Task;
import com.event_managment.service.TaskService;


@RestController
public class TaskController {

	@Autowired
	private TaskService service;

	@PostMapping("/task")
	public ResponseEntity<Task> saveTask(@RequestBody Task task) {

		return service.saveTask(task);
	}

	@GetMapping("/task/{id}")
	public ResponseEntity<Task> findTask(@PathVariable int id) {

		return service.findTask(id);
	}

	@PutMapping("/task/{id}")
	public ResponseEntity<Task> updateTask(@PathVariable int id, @RequestBody Task task) {

		return service.updateTask(task, id);
	}

	@DeleteMapping("/task/{id}")
	public ResponseEntity<Task> deleteTask(@PathVariable int id, @RequestBody Task task) {

		return service.deleteTask(task, id);
	}
}
