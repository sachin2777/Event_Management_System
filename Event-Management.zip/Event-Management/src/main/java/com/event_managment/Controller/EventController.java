package com.event_managment.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.event_managment.Entity.Event;
import com.event_managment.service.EventService;

@RestController
public class EventController {

	@Autowired
	private EventService service;

	@PostMapping("/event")
	public ResponseEntity<Event> saveEvent(@RequestBody Event event) {

		return service.saveEvent(event);
	}

	@GetMapping("/event/{id}")
	public ResponseEntity<Event> findEvent(@PathVariable int id) {

		return service.findEvent(id);
	}

	@PutMapping("/event/{id}")
	public ResponseEntity<Event> updateEvent(@PathVariable int id, @RequestBody Event event) {

		return service.updateEvent(event, id);
	}

	@DeleteMapping("/event/{id}")
	public ResponseEntity<Event> deleteEvent(@PathVariable int id, @RequestBody Event event) {

		return service.deleteEvent(event, id);
	}
}
