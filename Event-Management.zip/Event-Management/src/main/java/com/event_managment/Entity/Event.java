package com.event_managment.Entity;

import java.util.List;

import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Component
public class Event {
	
	@Id
	@GeneratedValue
	private int id ;
	private String name ;
	private String discription ;
	private String local ;
	private String date ;
	
	@OneToMany
	private List<Attendee> attendees ;
	
}
