package com.event_managment.Entity;

import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Component
@ToString
public class Attendee {
	
	@Id
	@GeneratedValue(strategy =GenerationType.SEQUENCE )
	private int id ;
	private String name ;
	private String gender ;
	
	@OneToOne
	@JoinColumn
	private Task task ;
	
}
