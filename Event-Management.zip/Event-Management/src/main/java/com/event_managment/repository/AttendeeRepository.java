package com.event_managment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.event_managment.Entity.Attendee;

public interface AttendeeRepository extends JpaRepository<Attendee, Integer> {

}
