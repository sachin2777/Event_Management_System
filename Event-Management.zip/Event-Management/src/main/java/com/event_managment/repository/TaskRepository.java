package com.event_managment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.event_managment.Entity.Task;

public interface TaskRepository extends JpaRepository<Task, Integer> {

}
