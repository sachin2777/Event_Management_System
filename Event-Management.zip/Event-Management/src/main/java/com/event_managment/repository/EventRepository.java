package com.event_managment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.event_managment.Entity.Event;

public interface EventRepository extends JpaRepository<Event, Integer> {

}
