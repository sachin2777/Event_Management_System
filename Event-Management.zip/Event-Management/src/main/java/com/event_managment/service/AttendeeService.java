package com.event_managment.service;

import java.util.Optional;

import javax.management.AttributeNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.event_managment.Entity.Attendee;
import com.event_managment.repository.AttendeeRepository;

@Service
public class AttendeeService {

	@Autowired
	private AttendeeRepository repository;

	public ResponseEntity<Attendee> saveAttendee(Attendee attendee) {
		
		System.out.println(attendee);
		
		if (attendee != null && attendee.getName() != null) {
			Attendee savedAttendee = repository.save(attendee);
			return new ResponseEntity<>(savedAttendee, HttpStatus.CREATED);
		} else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	public ResponseEntity<Attendee> findAttendee(int id) {
	    Optional<Attendee> foundAttendee = repository.findById(id);

	    if (foundAttendee.isPresent()) 
	        return new ResponseEntity<>(foundAttendee.get(), HttpStatus.OK); // 200 OK
	     else 
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	    
	}


	public ResponseEntity<Attendee> updateAttendee(Attendee attendee, int id) {
		
		
		 Attendee foundAttendee = repository.findById(id).get() ;
		

		if (foundAttendee != null && attendee.getName() != null) {
			foundAttendee.setGender(attendee.getGender());
			foundAttendee.setName(attendee.getName());
			foundAttendee.setTask(attendee.getTask());
			Attendee savedAttendee = repository.save(foundAttendee);
			return new ResponseEntity<>(savedAttendee, HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	public ResponseEntity<Attendee> deleteAttendee(Attendee attendee, int id) {

		 Attendee foundAttendee = repository.findById(id).get();
		
		if (foundAttendee != null) {
			
			  repository.delete(attendee);
			return ResponseEntity.ok(null) ;
		}
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}
}
