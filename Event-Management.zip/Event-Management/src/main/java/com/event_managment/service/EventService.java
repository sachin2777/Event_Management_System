package com.event_managment.service;

import java.util.Optional;

import javax.management.AttributeNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.event_managment.Entity.Event;
import com.event_managment.repository.EventRepository;
import com.event_managment.repository.EventRepository;

@Service
public class EventService {

	@Autowired
	private EventRepository repository;

	public ResponseEntity<Event> saveEvent(Event event) {
		
		System.out.println(event);
		
		if (event != null && event.getName() != null) {
			Event savedEvent = repository.save(event);
			return new ResponseEntity<>(savedEvent, HttpStatus.CREATED);
		} else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	public ResponseEntity<Event> findEvent(int id) {
	    Optional<Event> foundEvent = repository.findById(id);

	    if (foundEvent.isPresent()) 
	        return new ResponseEntity<>(foundEvent.get(), HttpStatus.OK); // 200 OK
	     else 
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	    
	}


	public ResponseEntity<Event> updateEvent(Event event, int id) {
		
		
		 Event foundEvent = repository.findById(id).get() ;
		

		if (foundEvent != null && event.getName() != null) {
			foundEvent.setAttendees(event.getAttendees());
			foundEvent.setName(event.getName());
			foundEvent.setDiscription(event.getDiscription());
			foundEvent.setLocal(event.getLocal());
			Event savedEvent = repository.save(foundEvent);
			return new ResponseEntity<>(savedEvent, HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	public ResponseEntity<Event> deleteEvent(Event event, int id) {

		 Event foundEvent = repository.findById(id).get();
		
		if (foundEvent != null) {
			
			  repository.delete(event);
			return ResponseEntity.ok(null) ;
		}
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}
}
