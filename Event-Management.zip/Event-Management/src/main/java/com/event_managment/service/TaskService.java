package com.event_managment.service;

import java.util.Optional;

import javax.management.AttributeNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.event_managment.Entity.Task;
import com.event_managment.repository.TaskRepository;

@Service
public class TaskService {

	@Autowired
	private TaskRepository repository;

	public ResponseEntity<Task> saveTask(Task task) {
		
		System.out.println(task);
		
		if (task != null && task.getName() != null) {
			Task savedTask = repository.save(task);
			return new ResponseEntity<>(savedTask, HttpStatus.CREATED);
		} else
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	public ResponseEntity<Task> findTask(int id) {
	    Optional<Task> foundTask = repository.findById(id);

	    if (foundTask.isPresent()) 
	        return new ResponseEntity<>(foundTask.get(), HttpStatus.OK); // 200 OK
	     else 
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND); // 404 Not Found
	    
	}


	public ResponseEntity<Task> updateTask(Task task, int id) {
		
		
		 Task foundTask = repository.findById(id).get() ;
		

		if (foundTask != null && task.getName() != null) {
			foundTask.setAttendee(task.getAttendee());
			foundTask.setDeadline(task.getDeadline());
			foundTask.setName(task.getName());
			Task savedTask = repository.save(foundTask);
			return new ResponseEntity<>(savedTask, HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}

	public ResponseEntity<Task> deleteTask(Task task, int id) {

		 Task foundTask = repository.findById(id).get();
		
		if (foundTask != null) {
			
			  repository.delete(task);
			return ResponseEntity.ok(null) ;
		}
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}
}
